How to run the tests:
1. Put exi.asm in the same folder as the .sh files for every i=1,...,5.
2. Run the command: "./qi_tester.sh" and replace i with 1,...,5 as needed.
